<?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layouts.main','data' => ['title' => 'Test KBM']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('layouts.main'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Test KBM']); ?>
  <div class="">
    <div class="my-4 px-6">
      <a href="<?php echo e(url('add')); ?>" class="focus:outline-none text-white bg-green-700 hover:bg-green-800 focus:ring-4 focus:ring-green-300 font-medium rounded-lg text-sm px-5 py-2.5 mr-2 mb-2 dark:bg-green-600 dark:hover:bg-green-700 dark:focus:ring-green-800">add</a>
    </div>
    <div class="relative overflow-x-auto shadow-md sm:rounded-lg">
      <table class="w-full text-sm text-left text-gray-500 dark:text-gray-400">
        <thead class="text-xs text-gray-700 uppercase bg-gray-50 dark:bg-gray-700 dark:text-gray-400">
          <tr>
            <th scope="col" class="px-6 py-3">
              Name
            </th>
            <th scope="col" class="px-6 py-3">
              Position
            </th>
            <th scope="col" class="px-6 py-3">
              Office
            </th>
            <th scope="col" class="px-6 py-3">
              Age
            </th>
            <th scope="col" class="px-6 py-3">
              Start Date
            </th>
            <th scope="col" class="px-6 py-3">
              <span class="">Action</span>
            </th>
          </tr>
        </thead>
        <tbody>
          <?php $__currentLoopData = $pegawai; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <tr class="bg-white border-b dark:bg-gray-800 dark:border-gray-700 hover:bg-gray-50 dark:hover:bg-gray-600">
            <th scope="row" class="px-6 py-4 font-medium text-gray-900 whitespace-nowrap dark:text-white">
              <?php echo e($row->name); ?>

            </th>
            <td class="px-6 py-4">
              <?php echo e($row->position); ?>

            </td>
            <td class="px-6 py-4">
              <?php echo e($row->office); ?>

            </td>
            <td class="px-6 py-4">
              <?php echo e($row->age); ?>

            </td>
            <td class="px-6 py-4">
              <?php echo e($row->start_date); ?>

            </td>
            <td class="px-6 py-4 text-right flex justify-end items-center gap-4 ">
              <form action="<?php echo e(url('/', ["id" => $row->id])); ?>" method="post">
                <?php echo csrf_field(); ?>
                <?php echo method_field("delete"); ?>
                <button class="font-medium text-red-600 dark:text-red-500 hover:underline">Delete</button>
              </form>
              <a href="<?php echo e(url('/edit', ['id' => $row->id])); ?>" class="font-medium text-blue-600 dark:text-blue-500 hover:underline">Edit</a>
            </td>
          </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
      </table>
    </div>
  </div>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
<?php /**PATH C:\Users\Tungtung\Desktop\test_kbm\resources\views/home.blade.php ENDPATH**/ ?>